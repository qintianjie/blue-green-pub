-- A test sample.
--
-- Author: qintianjie
-- Date:   2017-01-05

local modulename = "graypub.test"
local _M = {}
_M._VERSION = '1.0.0'
_M.k2="v2"

return _M